from django.shortcuts import render
from stock.models import Stock,Vente,Produit
# Create your views here.
def base(request):

    return render(request, 'edite_produit/index.html')

def editproduit(request):

    return render(request, 'edite_produit/produit.html')

def venteproduit(request):
    data=Vente.objects.all().order_by('-id')
    return render(request, 'edite_produit/vente.html',{'data':data})

def addvente(request):
    produit=Produit.objects.all()
    data={'produit':produit}
    if request.method == 'POST':
        recupere=request.POST
        nom_produit=Produit.objects.get(id=int(recupere.get('designation')))
        if Produit.diminue_qte(int(recupere.get('qte_achat'))):
            isinstance=Vente.objects.create(
                designation_produit=nom_produit,
                qte_achat=int(recupere.get('qte_achat')))
            print('le save a marché')
        print('le save ne mache pas ')
    return render(request, 'form_produit/addvente.html',data)

def addstock(request):
    produit=Produit.objects.all()
    data={'produit':produit}
    if request.method == 'POST':
        isinstance=request.POST
        #designation=Produit.objects.get(id=int(isinstance.get('designation')))
        if Produit.verif(str(isinstance.get('designation'))):
            toto=Stock.objects.create(
                produit=isinstance.get('designation'),
                qte_stock=isinstance.get('qte_stock')
            )
            print("Enregistrement a marché")
        print("Probleme de verification")
    print('ça n a pas marché')
    return render(request, 'form_produit/addstock.html',data)