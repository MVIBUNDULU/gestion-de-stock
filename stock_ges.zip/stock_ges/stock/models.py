from django.db import models
import uuid
# Create your models here.

class Produit(models.Model):
    designation=models.CharField(max_length=100)
    prix=models.IntegerField()
    date=models.DateField()
    secrete_key=models.UUIDField(default=uuid.uuid4)

    def __str__(self):

        return f"{self.designation} "
    
    def diminue_qte(self,qte):

        if(self.qte_produit.qte_stock >= qte):
            self.qte_produit.qte_stock -= qte
            self.qte_produit.save()
        False
#vérification si ce produit existe déjà dans le stock ou pas avant le save 
    def verif(self,designation,qte_stock):

        if(self.qte_produit.produit == designation):
            self.qte_produit.qte_stock +=qte_stock
            self.qte_produit.save()
        False

    
class Stock(models.Model):
    produit=models.OneToOneField(Produit ,on_delete=models.CASCADE, related_name="qte_produit")
    qte_stock=models.IntegerField()
    secrete_key=models.UUIDField(default=uuid.uuid4)
    
    def __str__(self):
        return f" Désignation {self.produit} Quantité: {self.qte_stock} "



class Vente(models.Model):
    designation_produit=models.ForeignKey(Produit,on_delete=models.CASCADE, related_name="qt_produit")
    qte_achat=models.IntegerField()
    pu=models.IntegerField(editable=False)
    pht=models.IntegerField(editable=False, default=0)
    secrete_key=models.UUIDField(default=uuid.uuid4)

    def __str__(self):

        return f"Désignation: {self.designation_produit} Quantité: {self.qte_achat} PU: {self.pu} PHT: {self.pht}"

    def save(self,*args,**kwargs):

        self.pu=self.designation_produit.prix
        self.pht=int(self.pu*self.qte_achat)
        super().save(*args,**kwargs)