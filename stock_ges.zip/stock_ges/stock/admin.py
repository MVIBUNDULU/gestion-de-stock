from django.contrib import admin
from stock.models import Stock, Vente, Produit
# Register your models here.

admin.site.register(Stock)
admin.site.register(Vente)
admin.site.register(Produit)