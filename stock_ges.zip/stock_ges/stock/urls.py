from django.urls import path
from stock import views
urlpatterns = [
    #path('admin/', admin.site.urls),
    path('', views.base, name='urlbase'),
    path('All produits', views.editproduit, name='urleditproduit'),
    path('All sell', views.venteproduit, name='urlvente'),
    path('Add sell', views.addvente, name='urladdvente'),
    path('Add stock', views.addstock, name='urladdstock'),
]